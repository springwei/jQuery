create database easyui;
use easyui;

CREATE TABLE e_organization (
  id INT(11),
  name VARCHAR(20)
);

CREATE TABLE e_user(
	id int primary key not null auto_increment,
	username varchar(10),
	orgname  varchar(10),
	state    varchar(10),
	loginname  varchar(20),
	ctime    date,
	orgId varchar(50),
	note  varchar(100)
);

insert into e_organization values(1,'总经办');
insert into e_organization values(2,'开发部');
insert into e_organization values(3,'测试部');

insert into e_user values('1','zhangsan','总经办','可用','zhangsan','2014-01-01','1','无');
insert into e_user values('2','just do it','测试部','可用','lisi','2014-01-01','3','');
insert into e_user values('3','牛牛','开发部','可用','niuniu','2014-01-01','2','技术大牛');